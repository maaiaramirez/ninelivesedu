// JavaScript para funcionalidades interactivas
document.addEventListener('DOMContentLoaded', function() {
    
    // Smooth scrolling para enlaces de navegación
    const navLinks = document.querySelectorAll('.nav-link[href^="#"]');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Efecto de scroll en el header
    window.addEventListener('scroll', function() {
        const header = document.querySelector('.header');
        if (window.scrollY > 100) {
            header.style.background = 'rgba(255, 255, 255, 0.98)';
            header.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
        } else {
            header.style.background = 'rgba(255, 255, 255, 0.95)';
            header.style.boxShadow = 'none';
        }
    });

    // Animaciones de entrada para las tarjetas
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Aplicar animaciones a las tarjetas
    const cards = document.querySelectorAll('.benefit-card, .testimonial-card');
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });

    // Funcionalidad de los botones principales
    const btnBuscarApuntes = document.querySelector('.btn-primary');
    const btnOfrecerTutorias = document.querySelector('.btn-secondary');
    const btnRegistro = document.querySelector('.btn-login');
    const btnTutor = document.querySelector('.btn-tutor');
    const btnCta = document.querySelector('.btn-cta');

    if (btnBuscarApuntes) {
        btnBuscarApuntes.addEventListener('click', function() {
            window.location.href = 'apuntes.html';
        });
    }

    if (btnOfrecerTutorias) {
        btnOfrecerTutorias.addEventListener('click', function() {
            window.location.href = 'tutores.html';
        });
    }

    if (btnRegistro) {
        btnRegistro.addEventListener('click', function() {
            showModal('login');
        });
    }

    if (btnTutor) {
        btnTutor.addEventListener('click', function() {
            showModal('tutor');
        });
    }

    if (btnCta) {
        btnCta.addEventListener('click', function() {
            showModal('register');
        });
    }

    // Función para mostrar modales
    function showModal(type) {
        // Crear overlay
        const overlay = document.createElement('div');
        overlay.className = 'modal-overlay';
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
        `;

        // Crear modal
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.cssText = `
            background: white;
            padding: 2rem;
            border-radius: 20px;
            max-width: 400px;
            width: 90%;
            text-align: center;
        `;

        let modalContent = '';
        
        if (type === 'login') {
            modalContent = `
                <h2 style="margin-bottom: 1rem; color: #333;">Iniciar Sesión</h2>
                <form>
                    <input type="email" placeholder="Correo electrónico" style="width: 100%; padding: 1rem; margin-bottom: 1rem; border: 1px solid #ddd; border-radius: 10px;">
                    <input type="password" placeholder="Contraseña" style="width: 100%; padding: 1rem; margin-bottom: 1rem; border: 1px solid #ddd; border-radius: 10px;">
                    <button type="submit" style="width: 100%; padding: 1rem; background: linear-gradient(135deg, #8b5cf6, #ec4899); color: white; border: none; border-radius: 10px; font-weight: 600; cursor: pointer;">Iniciar Sesión</button>
                </form>
                <p style="margin-top: 1rem; color: #666;">¿No tienes cuenta? <a href="#" style="color: #8b5cf6;">Regístrate aquí</a></p>
            `;
        } else if (type === 'register') {
            modalContent = `
                <h2 style="margin-bottom: 1rem; color: #333;">Registrarse</h2>
                <form>
                    <input type="text" placeholder="Nombre completo" style="width: 100%; padding: 1rem; margin-bottom: 1rem; border: 1px solid #ddd; border-radius: 10px;">
                    <input type="email" placeholder="Correo electrónico" style="width: 100%; padding: 1rem; margin-bottom: 1rem; border: 1px solid #ddd; border-radius: 10px;">
                    <input type="password" placeholder="Contraseña" style="width: 100%; padding: 1rem; margin-bottom: 1rem; border: 1px solid #ddd; border-radius: 10px;">
                    <button type="submit" style="width: 100%; padding: 1rem; background: linear-gradient(135deg, #8b5cf6, #ec4899); color: white; border: none; border-radius: 10px; font-weight: 600; cursor: pointer;">Registrarse</button>
                </form>
                <p style="margin-top: 1rem; color: #666;">¿Ya tienes cuenta? <a href="#" style="color: #8b5cf6;">Inicia sesión aquí</a></p>
            `;
        } else if (type === 'tutor') {
            modalContent = `
                <h2 style="margin-bottom: 1rem; color: #333;">Unirse como Tutor</h2>
                <p style="margin-bottom: 1.5rem; color: #666;">Completa el formulario para convertirte en tutor y empezar a ganar dinero enseñando.</p>
                <form>
                    <input type="text" placeholder="Nombre completo" style="width: 100%; padding: 1rem; margin-bottom: 1rem; border: 1px solid #ddd; border-radius: 10px;">
                    <input type="email" placeholder="Correo electrónico" style="width: 100%; padding: 1rem; margin-bottom: 1rem; border: 1px solid #ddd; border-radius: 10px;">
                    <select style="width: 100%; padding: 1rem; margin-bottom: 1rem; border: 1px solid #ddd; border-radius: 10px;">
                        <option>Selecciona tu especialidad</option>
                        <option>Matemáticas</option>
                        <option>Física</option>
                        <option>Química</option>
                        <option>Biología</option>
                        <option>Historia</option>
                        <option>Literatura</option>
                        <option>Inglés</option>
                    </select>
                    <button type="submit" style="width: 100%; padding: 1rem; background: linear-gradient(135deg, #ff6b35, #f97316); color: white; border: none; border-radius: 10px; font-weight: 600; cursor: pointer;">Enviar Solicitud</button>
                </form>
            `;
        }

        modal.innerHTML = modalContent;

        // Botón de cerrar
        const closeBtn = document.createElement('button');
        closeBtn.innerHTML = '×';
        closeBtn.style.cssText = `
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #666;
        `;

        modal.style.position = 'relative';
        modal.appendChild(closeBtn);

        overlay.appendChild(modal);
        document.body.appendChild(overlay);

        // Cerrar modal
        function closeModal() {
            document.body.removeChild(overlay);
        }

        closeBtn.addEventListener('click', closeModal);
        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) {
                closeModal();
            }
        });

        // Prevenir envío de formularios
        const form = modal.querySelector('form');
        if (form) {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                alert('¡Gracias! Te contactaremos pronto.');
                closeModal();
            });
        }
    }

    // Efecto parallax suave en el hero
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const hero = document.querySelector('.hero');
        if (hero) {
            hero.style.transform = `translateY(${scrolled * 0.5}px)`;
        }
    });

    // Contador animado para estadísticas (si se agregan)
    function animateCounter(element, target) {
        let current = 0;
        const increment = target / 100;
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            element.textContent = Math.floor(current);
        }, 20);
    }

    // Lazy loading para imágenes
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });

    images.forEach(img => imageObserver.observe(img));
});
