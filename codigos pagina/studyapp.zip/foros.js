// JavaScript específico para la página de foros
document.addEventListener('DOMContentLoaded', function() {
    
    // Datos de ejemplo para los posts
    const postsData = [
        {
            id: 1,
            titulo: "¿Cómo resolver ecuaciones cuadráticas por factorización?",
            contenido: "Estoy teniendo problemas para entender cómo factorizar ecuaciones cuadráticas. ¿Alguien puede explicarme el proceso paso a paso con ejemplos?",
            autor: "Carlos M.",
            fecha: "2024-01-15",
            nivel: "secundaria",
            materia: "matematicas",
            tipo: "pregunta",
            tags: ["ecuaciones", "factorización", "álgebra"],
            votos: 12,
            respuestas: 8,
            vistas: 156,
            resuelto: false
        },
        {
            id: 2,
            titulo: "Debate: ¿Es mejor estudiar en grupo o individualmente?",
            contenido: "Quiero conocer sus opiniones sobre los pros y contras de estudiar en grupo versus estudiar solo. ¿Cuál método prefieren y por qué?",
            autor: "Ana L.",
            fecha: "2024-01-14",
            nivel: "universidad",
            materia: "general",
            tipo: "debate",
            tags: ["estudio", "métodos", "productividad"],
            votos: 25,
            respuestas: 15,
            vistas: 234,
            resuelto: false
        },
        {
            id: 3,
            titulo: "Recursos útiles para aprender Física Cuántica",
            contenido: "Comparto una lista de recursos que me han ayudado mucho en mi curso de física cuántica: libros, videos, simulaciones y ejercicios prácticos.",
            autor: "Prof. Miguel T.",
            fecha: "2024-01-13",
            nivel: "universidad",
            materia: "fisica",
            tipo: "recurso",
            tags: ["física cuántica", "recursos", "libros"],
            votos: 18,
            respuestas: 5,
            vistas: 189,
            resuelto: false
        },
        {
            id: 4,
            titulo: "Anuncio: Nuevo grupo de estudio de Química Orgánica",
            contenido: "Estoy formando un grupo de estudio para química orgánica. Nos reuniremos los martes y jueves a las 7 PM. ¡Interesados contactenme!",
            autor: "Dra. Patricia V.",
            fecha: "2024-01-12",
            nivel: "universidad",
            materia: "quimica",
            tipo: "anuncio",
            tags: ["grupo de estudio", "química orgánica", "reuniones"],
            votos: 7,
            respuestas: 3,
            vistas: 98,
            resuelto: false
        },
        {
            id: 5,
            titulo: "¿Cuál es la diferencia entre mitosis y meiosis?",
            contenido: "Necesito ayuda para entender las diferencias principales entre mitosis y meiosis. ¿Pueden explicarme cada proceso y sus diferencias?",
            autor: "Laura S.",
            fecha: "2024-01-11",
            nivel: "bachillerato",
            materia: "biologia",
            tipo: "pregunta",
            tags: ["mitosis", "meiosis", "división celular"],
            votos: 9,
            respuestas: 6,
            vistas: 127,
            resuelto: true
        },
        {
            id: 6,
            titulo: "Técnicas de memorización para Historia",
            contenido: "Comparto algunas técnicas que uso para memorizar fechas y eventos históricos. Espero que les sean útiles para sus exámenes.",
            autor: "Diego R.",
            fecha: "2024-01-10",
            nivel: "secundaria",
            materia: "historia",
            tipo: "recurso",
            tags: ["memorización", "historia", "técnicas"],
            votos: 14,
            respuestas: 4,
            vistas: 145,
            resuelto: false
        },
        {
            id: 7,
            titulo: "¿Cómo mejorar mi comprensión lectora en Literatura?",
            contenido: "Tengo dificultades para entender textos literarios complejos. ¿Qué estrategias puedo usar para mejorar mi comprensión lectora?",
            autor: "Sofia C.",
            fecha: "2024-01-09",
            nivel: "bachillerato",
            materia: "literatura",
            tipo: "pregunta",
            tags: ["comprensión lectora", "literatura", "estrategias"],
            votos: 11,
            respuestas: 7,
            vistas: 167,
            resuelto: false
        },
        {
            id: 8,
            titulo: "Debate: ¿Debería ser obligatorio el inglés en la universidad?",
            contenido: "¿Qué opinan sobre hacer obligatorio el inglés en todas las carreras universitarias? ¿Creen que es necesario o debería ser opcional?",
            autor: "Roberto V.",
            fecha: "2024-01-08",
            nivel: "universidad",
            materia: "ingles",
            tipo: "debate",
            tags: ["inglés", "universidad", "obligatorio"],
            votos: 22,
            respuestas: 18,
            vistas: 298,
            resuelto: false
        }
    ];

    let currentView = 'list';
    let filteredPosts = [...postsData];

    // Inicializar la página
    initForosPage();

    function initForosPage() {
        renderPosts(filteredPosts);
        setupEventListeners();
        updateResultsCount();
    }

    function setupEventListeners() {
        // Búsqueda
        const searchInput = document.getElementById('searchInput');
        const searchBtn = document.querySelector('.search-btn');
        
        if (searchInput) {
            searchInput.addEventListener('input', handleSearch);
        }
        
        if (searchBtn) {
            searchBtn.addEventListener('click', handleSearch);
        }

        // Filtros
        const nivelFilter = document.getElementById('nivelFilter');
        const materiaFilter = document.getElementById('materiaFilter');
        const tipoFilter = document.getElementById('tipoFilter');
        const ordenFilter = document.getElementById('ordenFilter');

        if (nivelFilter) {
            nivelFilter.addEventListener('change', applyFilters);
        }
        if (materiaFilter) {
            materiaFilter.addEventListener('change', applyFilters);
        }
        if (tipoFilter) {
            tipoFilter.addEventListener('change', applyFilters);
        }
        if (ordenFilter) {
            ordenFilter.addEventListener('change', applyFilters);
        }

        // Categorías
        const categoryItems = document.querySelectorAll('.category-item');
        categoryItems.forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const nivel = this.dataset.nivel;
                const materia = this.dataset.materia;
                
                if (nivel) {
                    document.getElementById('nivelFilter').value = nivel;
                }
                if (materia) {
                    document.getElementById('materiaFilter').value = materia;
                }
                
                applyFilters();
            });
        });

        // Cambio de vista
        const viewBtns = document.querySelectorAll('.view-btn');
        viewBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                currentView = this.dataset.view;
                updateViewButtons();
                renderPosts(filteredPosts);
            });
        });

        // Botón nuevo post
        const btnNuevoPost = document.querySelector('.btn-nuevo-post');
        if (btnNuevoPost) {
            btnNuevoPost.addEventListener('click', showNewPostModal);
        }

        // Modales
        setupModals();
    }

    function handleSearch() {
        const searchTerm = document.getElementById('searchInput').value.toLowerCase();
        
        filteredPosts = postsData.filter(post => 
            post.titulo.toLowerCase().includes(searchTerm) ||
            post.contenido.toLowerCase().includes(searchTerm) ||
            post.tags.some(tag => tag.toLowerCase().includes(searchTerm)) ||
            post.autor.toLowerCase().includes(searchTerm)
        );
        
        applyFilters();
    }

    function applyFilters() {
        let filtered = [...postsData];

        // Filtro de búsqueda
        const searchTerm = document.getElementById('searchInput').value.toLowerCase();
        if (searchTerm) {
            filtered = filtered.filter(post => 
                post.titulo.toLowerCase().includes(searchTerm) ||
                post.contenido.toLowerCase().includes(searchTerm) ||
                post.tags.some(tag => tag.toLowerCase().includes(searchTerm)) ||
                post.autor.toLowerCase().includes(searchTerm)
            );
        }

        // Filtro de nivel
        const nivelFilter = document.getElementById('nivelFilter').value;
        if (nivelFilter) {
            filtered = filtered.filter(post => post.nivel === nivelFilter);
        }

        // Filtro de materia
        const materiaFilter = document.getElementById('materiaFilter').value;
        if (materiaFilter) {
            filtered = filtered.filter(post => post.materia === materiaFilter);
        }

        // Filtro de tipo
        const tipoFilter = document.getElementById('tipoFilter').value;
        if (tipoFilter) {
            filtered = filtered.filter(post => post.tipo === tipoFilter);
        }

        // Ordenamiento
        const ordenFilter = document.getElementById('ordenFilter').value;
        switch (ordenFilter) {
            case 'reciente':
                filtered.sort((a, b) => new Date(b.fecha) - new Date(a.fecha));
                break;
            case 'popular':
                filtered.sort((a, b) => b.votos - a.votos);
                break;
            case 'respuestas':
                filtered.sort((a, b) => b.respuestas - a.respuestas);
                break;
            case 'votos':
                filtered.sort((a, b) => b.votos - a.votos);
                break;
        }

        filteredPosts = filtered;
        renderPosts(filteredPosts);
        updateResultsCount();
    }

    function renderPosts(posts) {
        const container = document.getElementById('postsContainer');
        if (!container) return;

        if (posts.length === 0) {
            container.innerHTML = `
                <div class="no-results">
                    <i class="fas fa-search" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>
                    <h3>No se encontraron posts</h3>
                    <p>Intenta ajustar tus filtros de búsqueda</p>
                </div>
            `;
            return;
        }

        const postsHTML = posts.map(post => createPostCard(post)).join('');
        container.innerHTML = postsHTML;
        
        // Agregar clase de vista
        container.className = `posts-container ${currentView === 'grid' ? 'grid-view' : ''}`;
        
        // Agregar event listeners
        setupPostEventListeners();
    }

    function createPostCard(post) {
        const tagsHTML = post.tags.map(tag => 
            `<span class="post-tag">${tag}</span>`
        ).join('');

        const resueltoBadge = post.resuelto ? '<span class="post-type-badge resuelto">✓ Resuelto</span>' : '';

        return `
            <div class="post-card ${post.tipo}" data-id="${post.id}">
                <div class="post-header">
                    <div class="post-author-avatar">
                        ${post.autor.charAt(0)}
                    </div>
                    <div class="post-meta">
                        <div class="post-author">${post.autor}</div>
                        <div class="post-date">${formatDate(post.fecha)}</div>
                    </div>
                    <div class="post-type-badge ${post.tipo}">${post.tipo}</div>
                    ${resueltoBadge}
                </div>
                
                <div class="post-content">
                    <h3 class="post-title">${post.titulo}</h3>
                    <p class="post-preview">${post.contenido.substring(0, 150)}${post.contenido.length > 150 ? '...' : ''}</p>
                    <div class="post-tags">${tagsHTML}</div>
                </div>
                
                <div class="post-footer">
                    <div class="post-stats">
                        <div class="post-stat">
                            <i class="fas fa-thumbs-up"></i>
                            <span>${post.votos}</span>
                        </div>
                        <div class="post-stat">
                            <i class="fas fa-comments"></i>
                            <span>${post.respuestas}</span>
                        </div>
                        <div class="post-stat">
                            <i class="fas fa-eye"></i>
                            <span>${post.vistas}</span>
                        </div>
                    </div>
                    
                    <div class="post-actions">
                        <button class="btn-action btn-vote" data-id="${post.id}">
                            <i class="fas fa-thumbs-up"></i>
                        </button>
                        <button class="btn-action btn-responder" data-id="${post.id}">
                            Responder
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    function setupPostEventListeners() {
        // Botones de votar
        document.querySelectorAll('.btn-vote').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                const postId = this.dataset.id;
                votePost(postId);
            });
        });

        // Botones de responder
        document.querySelectorAll('.btn-responder').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                const postId = this.dataset.id;
                showPostModal(postId);
            });
        });

        // Click en post para ver completo
        document.querySelectorAll('.post-card').forEach(card => {
            card.addEventListener('click', function() {
                const postId = this.dataset.id;
                showPostModal(postId);
            });
        });
    }

    function votePost(postId) {
        const post = postsData.find(p => p.id == postId);
        if (post) {
            post.votos++;
            renderPosts(filteredPosts);
            
            // Mostrar feedback visual
            const btn = document.querySelector(`[data-id="${postId}"].btn-vote`);
            if (btn) {
                btn.classList.add('voted');
                setTimeout(() => {
                    btn.classList.remove('voted');
                }, 1000);
            }
        }
    }

    function showPostModal(postId) {
        const post = postsData.find(p => p.id == postId);
        if (!post) return;

        const modal = document.getElementById('postModal');
        
        // Llenar información del modal
        document.getElementById('postModalTitle').textContent = post.titulo;
        
        const postContent = `
            <div class="post-header">
                <div class="post-author-avatar">
                    ${post.autor.charAt(0)}
                </div>
                <div class="post-meta">
                    <div class="post-author">${post.autor}</div>
                    <div class="post-date">${formatDate(post.fecha)}</div>
                </div>
                <div class="post-type-badge ${post.tipo}">${post.tipo}</div>
            </div>
            <div class="post-content">
                <p>${post.contenido}</p>
                <div class="post-tags">
                    ${post.tags.map(tag => `<span class="post-tag">${tag}</span>`).join('')}
                </div>
            </div>
        `;
        
        document.getElementById('postModalContent').innerHTML = postContent;
        
        // Simular respuestas
        const respuestas = generateMockResponses(post);
        const respuestasHTML = respuestas.map(respuesta => `
            <div class="response-item">
                <div class="response-header">
                    <div class="response-author-avatar">${respuesta.autor.charAt(0)}</div>
                    <div class="response-author">${respuesta.autor}</div>
                    <div class="response-date">${formatDate(respuesta.fecha)}</div>
                </div>
                <div class="response-text">${respuesta.texto}</div>
            </div>
        `).join('');
        
        document.getElementById('postModalResponses').innerHTML = respuestasHTML;
        
        // Mostrar modal
        modal.style.display = 'flex';
    }

    function generateMockResponses(post) {
        const respuestas = [
            {
                autor: "Prof. María G.",
                fecha: "2024-01-15",
                texto: "Excelente pregunta. Te explico el proceso paso a paso..."
            },
            {
                autor: "Carlos R.",
                fecha: "2024-01-15",
                texto: "También puedes usar la fórmula cuadrática como alternativa..."
            },
            {
                autor: "Ana S.",
                fecha: "2024-01-14",
                texto: "Me ayudó mucho tu explicación, gracias por compartir."
            }
        ];
        
        return respuestas.slice(0, Math.min(post.respuestas, 3));
    }

    function showNewPostModal() {
        const modal = document.getElementById('newPostModal');
        modal.style.display = 'flex';
    }

    function setupModals() {
        // Modal nuevo post
        const newPostModal = document.getElementById('newPostModal');
        const closeNewPost = newPostModal.querySelector('.close-modal');
        const cancelNewPost = newPostModal.querySelector('.btn-cancel');
        const newPostForm = document.getElementById('newPostForm');

        function closeNewPostModal() {
            newPostModal.style.display = 'none';
        }

        if (closeNewPost) {
            closeNewPost.addEventListener('click', closeNewPostModal);
        }

        if (cancelNewPost) {
            cancelNewPost.addEventListener('click', closeNewPostModal);
        }

        if (newPostForm) {
            newPostForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const titulo = document.getElementById('postTitulo').value;
                const contenido = document.getElementById('postContenido').value;
                
                // Simular creación de post
                alert(`¡Post "${titulo}" creado exitosamente!`);
                closeNewPostModal();
                
                // Limpiar formulario
                this.reset();
            });
        }

        // Modal post completo
        const postModal = document.getElementById('postModal');
        const closePost = postModal.querySelector('.close-modal');
        const addResponseBtn = postModal.querySelector('.btn-add-response');

        function closePostModal() {
            postModal.style.display = 'none';
        }

        if (closePost) {
            closePost.addEventListener('click', closePostModal);
        }

        if (addResponseBtn) {
            addResponseBtn.addEventListener('click', function() {
                const responseText = document.getElementById('responseText').value;
                if (responseText.trim()) {
                    alert('¡Respuesta enviada exitosamente!');
                    document.getElementById('responseText').value = '';
                }
            });
        }

        // Cerrar modales al hacer clic fuera
        [newPostModal, postModal].forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    modal.style.display = 'none';
                }
            });
        });
    }

    function updateViewButtons() {
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.view === currentView) {
                btn.classList.add('active');
            }
        });
    }

    function updateResultsCount() {
        const countElement = document.getElementById('resultsCount');
        if (countElement) {
            countElement.textContent = `Mostrando ${filteredPosts.length} posts`;
        }
    }

    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('es-ES', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
});
