// JavaScript específico para la página de tutores
document.addEventListener('DOMContentLoaded', function() {
    
    // Datos de ejemplo para los tutores
    const tutoresData = [
        {
            id: 1,
            nombre: "Dr. María González",
            materia: "matematicas",
            nivel: "universidad",
            precio: 35,
            rating: 4.9,
            experiencia: "8 años",
            foto: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
            biografia: "Doctora en Matemáticas con más de 8 años de experiencia enseñando cálculo, álgebra y estadística. Especializada en preparación para exámenes universitarios.",
            materias: ["Cálculo", "Álgebra", "Estadística", "Geometría"],
            disponibilidad: {
                lunes: "mañana",
                martes: "tarde",
                miercoles: "mañana",
                jueves: "tarde",
                viernes: "mañana",
                sabado: "disponible",
                domingo: "no disponible"
            },
            idiomas: ["español", "ingles"],
            reseñas: [
                { autor: "Carlos M.", rating: 5, texto: "Excelente profesora, muy clara en sus explicaciones." },
                { autor: "Ana L.", rating: 5, texto: "Me ayudó mucho con cálculo diferencial." },
                { autor: "Pedro R.", rating: 4, texto: "Muy paciente y dedicada." }
            ]
        },
        {
            id: 2,
            nombre: "Prof. Carlos Ruiz",
            materia: "fisica",
            nivel: "bachillerato",
            precio: 25,
            rating: 4.7,
            experiencia: "5 años",
            foto: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
            biografia: "Ingeniero Físico con amplia experiencia en enseñanza de física a nivel bachillerato. Especializado en mecánica y termodinámica.",
            materias: ["Física", "Mecánica", "Termodinámica", "Óptica"],
            disponibilidad: {
                lunes: "tarde",
                martes: "mañana",
                miercoles: "tarde",
                jueves: "mañana",
                viernes: "tarde",
                sabado: "disponible",
                domingo: "disponible"
            },
            idiomas: ["español"],
            reseñas: [
                { autor: "Laura S.", rating: 5, texto: "Muy bueno explicando conceptos difíciles." },
                { autor: "Miguel T.", rating: 4, texto: "Clases muy dinámicas y entretenidas." }
            ]
        },
        {
            id: 3,
            nombre: "Dra. Ana Martínez",
            materia: "quimica",
            nivel: "universidad",
            precio: 30,
            rating: 4.8,
            experiencia: "6 años",
            foto: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
            biografia: "Doctora en Química Orgánica con experiencia en investigación y docencia universitaria. Especializada en química orgánica y bioquímica.",
            materias: ["Química Orgánica", "Bioquímica", "Química Inorgánica", "Fisicoquímica"],
            disponibilidad: {
                lunes: "mañana",
                martes: "no disponible",
                miercoles: "mañana",
                jueves: "tarde",
                viernes: "mañana",
                sabado: "no disponible",
                domingo: "no disponible"
            },
            idiomas: ["español", "ingles"],
            reseñas: [
                { autor: "Roberto V.", rating: 5, texto: "Increíble profesora, muy detallada." },
                { autor: "Sofia C.", rating: 5, texto: "Me salvó en química orgánica." }
            ]
        },
        {
            id: 4,
            nombre: "Prof. Luis García",
            materia: "historia",
            nivel: "secundaria",
            precio: 20,
            rating: 4.6,
            experiencia: "4 años",
            foto: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
            biografia: "Licenciado en Historia con especialización en historia universal y arte. Experiencia enseñando a estudiantes de secundaria.",
            materias: ["Historia Universal", "Historia del Arte", "Geografía", "Ciencias Sociales"],
            disponibilidad: {
                lunes: "tarde",
                martes: "tarde",
                miercoles: "tarde",
                jueves: "tarde",
                viernes: "tarde",
                sabado: "disponible",
                domingo: "disponible"
            },
            idiomas: ["español"],
            reseñas: [
                { autor: "Elena P.", rating: 4, texto: "Muy interesante, hace la historia divertida." },
                { autor: "Diego M.", rating: 5, texto: "Excelente profesor, muy preparado." }
            ]
        },
        {
            id: 5,
            nombre: "Dra. Carmen López",
            materia: "literatura",
            nivel: "bachillerato",
            precio: 28,
            rating: 4.9,
            experiencia: "7 años",
            foto: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face",
            biografia: "Doctora en Literatura Española con amplia experiencia en análisis literario y redacción. Especializada en literatura clásica y contemporánea.",
            materias: ["Literatura Española", "Redacción", "Análisis Literario", "Lingüística"],
            disponibilidad: {
                lunes: "mañana",
                martes: "mañana",
                miercoles: "no disponible",
                jueves: "mañana",
                viernes: "mañana",
                sabado: "disponible",
                domingo: "no disponible"
            },
            idiomas: ["español", "frances"],
            reseñas: [
                { autor: "Isabel R.", rating: 5, texto: "Mejor profesora de literatura que he tenido." },
                { autor: "Antonio G.", rating: 5, texto: "Muy buena para análisis de textos." }
            ]
        },
        {
            id: 6,
            nombre: "Prof. John Smith",
            materia: "ingles",
            nivel: "universidad",
            precio: 40,
            rating: 4.8,
            experiencia: "10 años",
            foto: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face",
            biografia: "Nativo inglés con certificación TESOL y más de 10 años de experiencia enseñando inglés como segunda lengua. Especializado en preparación para exámenes internacionales.",
            materias: ["Inglés Conversacional", "TOEFL", "IELTS", "Business English"],
            disponibilidad: {
                lunes: "disponible",
                martes: "disponible",
                miercoles: "disponible",
                jueves: "disponible",
                viernes: "disponible",
                sabado: "disponible",
                domingo: "disponible"
            },
            idiomas: ["ingles", "español"],
            reseñas: [
                { autor: "María F.", rating: 5, texto: "Nativo perfecto, muy profesional." },
                { autor: "Carlos D.", rating: 4, texto: "Excelente para preparar TOEFL." }
            ]
        },
        {
            id: 7,
            nombre: "Dra. Patricia Vega",
            materia: "biologia",
            nivel: "universidad",
            precio: 32,
            rating: 4.7,
            experiencia: "6 años",
            foto: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=150&h=150&fit=crop&crop=face",
            biografia: "Doctora en Biología Molecular con experiencia en investigación y docencia. Especializada en biología celular y genética.",
            materias: ["Biología Celular", "Genética", "Microbiología", "Ecología"],
            disponibilidad: {
                lunes: "tarde",
                martes: "mañana",
                miercoles: "tarde",
                jueves: "mañana",
                viernes: "tarde",
                sabado: "no disponible",
                domingo: "no disponible"
            },
            idiomas: ["español", "ingles"],
            reseñas: [
                { autor: "Alejandro H.", rating: 5, texto: "Muy clara en sus explicaciones de biología." },
                { autor: "Valeria M.", rating: 4, texto: "Excelente para genética." }
            ]
        },
        {
            id: 8,
            nombre: "Prof. Miguel Torres",
            materia: "filosofia",
            nivel: "bachillerato",
            precio: 22,
            rating: 4.5,
            experiencia: "3 años",
            foto: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&h=150&fit=crop&crop=face",
            biografia: "Licenciado en Filosofía con especialización en filosofía moderna y ética. Experiencia enseñando a estudiantes de bachillerato.",
            materias: ["Filosofía Moderna", "Ética", "Lógica", "Historia de la Filosofía"],
            disponibilidad: {
                lunes: "noche",
                martes: "noche",
                miercoles: "noche",
                jueves: "noche",
                viernes: "noche",
                sabado: "disponible",
                domingo: "disponible"
            },
            idiomas: ["español"],
            reseñas: [
                { autor: "Gabriel L.", rating: 4, texto: "Muy bueno para entender conceptos filosóficos." },
                { autor: "Natalia K.", rating: 5, texto: "Hace la filosofía muy interesante." }
            ]
        }
    ];

    let currentView = 'grid';
    let filteredTutores = [...tutoresData];

    // Inicializar la página
    initTutoresPage();

    function initTutoresPage() {
        renderTutores(filteredTutores);
        setupEventListeners();
        updateResultsCount();
    }

    function setupEventListeners() {
        // Búsqueda
        const searchInput = document.getElementById('searchInput');
        const searchBtn = document.querySelector('.search-btn');
        
        if (searchInput) {
            searchInput.addEventListener('input', handleSearch);
        }
        
        if (searchBtn) {
            searchBtn.addEventListener('click', handleSearch);
        }

        // Filtros
        const nivelFilter = document.getElementById('nivelFilter');
        const materiaFilter = document.getElementById('materiaFilter');
        const precioFilter = document.getElementById('precioFilter');
        const ratingFilter = document.getElementById('ratingFilter');

        if (nivelFilter) {
            nivelFilter.addEventListener('change', applyFilters);
        }
        if (materiaFilter) {
            materiaFilter.addEventListener('change', applyFilters);
        }
        if (precioFilter) {
            precioFilter.addEventListener('change', applyFilters);
        }
        if (ratingFilter) {
            ratingFilter.addEventListener('change', applyFilters);
        }

        // Filtros adicionales
        const checkboxes = document.querySelectorAll('.availability-filter input[type="checkbox"], .language-filter input[type="checkbox"]');
        const radios = document.querySelectorAll('.experience-filter input[type="radio"]');
        
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', applyFilters);
        });
        
        radios.forEach(radio => {
            radio.addEventListener('change', applyFilters);
        });

        // Cambio de vista
        const viewBtns = document.querySelectorAll('.view-btn');
        viewBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                currentView = this.dataset.view;
                updateViewButtons();
                renderTutores(filteredTutores);
            });
        });

        // Limpiar filtros
        const btnLimpiarFiltros = document.querySelector('.btn-limpiar-filtros');
        if (btnLimpiarFiltros) {
            btnLimpiarFiltros.addEventListener('click', clearFilters);
        }

        // Modal de tutor
        setupTutorModal();
    }

    function handleSearch() {
        const searchTerm = document.getElementById('searchInput').value.toLowerCase();
        
        filteredTutores = tutoresData.filter(tutor => 
            tutor.nombre.toLowerCase().includes(searchTerm) ||
            tutor.materia.toLowerCase().includes(searchTerm) ||
            tutor.materias.some(materia => materia.toLowerCase().includes(searchTerm))
        );
        
        applyFilters();
    }

    function applyFilters() {
        let filtered = [...tutoresData];

        // Filtro de búsqueda
        const searchTerm = document.getElementById('searchInput').value.toLowerCase();
        if (searchTerm) {
            filtered = filtered.filter(tutor => 
                tutor.nombre.toLowerCase().includes(searchTerm) ||
                tutor.materia.toLowerCase().includes(searchTerm) ||
                tutor.materias.some(materia => materia.toLowerCase().includes(searchTerm))
            );
        }

        // Filtro de nivel
        const nivelFilter = document.getElementById('nivelFilter').value;
        if (nivelFilter) {
            filtered = filtered.filter(tutor => tutor.nivel === nivelFilter);
        }

        // Filtro de materia
        const materiaFilter = document.getElementById('materiaFilter').value;
        if (materiaFilter) {
            filtered = filtered.filter(tutor => tutor.materia === materiaFilter);
        }

        // Filtro de precio
        const precioFilter = document.getElementById('precioFilter').value;
        if (precioFilter) {
            const [min, max] = precioFilter.split('-').map(p => p.replace('+', ''));
            filtered = filtered.filter(tutor => {
                if (max === undefined) {
                    return tutor.precio >= parseInt(min);
                }
                return tutor.precio >= parseInt(min) && tutor.precio <= parseInt(max);
            });
        }

        // Filtro de valoración
        const ratingFilter = document.getElementById('ratingFilter').value;
        if (ratingFilter) {
            const minRating = parseFloat(ratingFilter);
            filtered = filtered.filter(tutor => tutor.rating >= minRating);
        }

        // Filtro de disponibilidad
        const availabilityCheckboxes = document.querySelectorAll('.availability-filter input[type="checkbox"]:checked');
        if (availabilityCheckboxes.length > 0) {
            const disponibilidadesSeleccionadas = Array.from(availabilityCheckboxes).map(cb => cb.value);
            filtered = filtered.filter(tutor => {
                return Object.values(tutor.disponibilidad).some(disp => 
                    disponibilidadesSeleccionadas.includes(disp) || disp === 'disponible'
                );
            });
        }

        // Filtro de idioma
        const languageCheckboxes = document.querySelectorAll('.language-filter input[type="checkbox"]:checked');
        if (languageCheckboxes.length > 0) {
            const idiomasSeleccionados = Array.from(languageCheckboxes).map(cb => cb.value);
            filtered = filtered.filter(tutor => 
                tutor.idiomas.some(idioma => idiomasSeleccionados.includes(idioma))
            );
        }

        // Filtro de experiencia
        const experienceRadio = document.querySelector('.experience-filter input[type="radio"]:checked');
        if (experienceRadio) {
            const experienciaMinima = experienceRadio.value;
            filtered = filtered.filter(tutor => {
                const añosExperiencia = parseInt(tutor.experiencia);
                switch (experienciaMinima) {
                    case '5+':
                        return añosExperiencia >= 5;
                    case '3-5':
                        return añosExperiencia >= 3 && añosExperiencia <= 5;
                    case '1-3':
                        return añosExperiencia >= 1 && añosExperiencia <= 3;
                    default:
                        return true;
                }
            });
        }

        filteredTutores = filtered;
        renderTutores(filteredTutores);
        updateResultsCount();
    }

    function clearFilters() {
        // Limpiar búsqueda
        document.getElementById('searchInput').value = '';
        
        // Limpiar filtros principales
        document.getElementById('nivelFilter').value = '';
        document.getElementById('materiaFilter').value = '';
        document.getElementById('precioFilter').value = '';
        document.getElementById('ratingFilter').value = '';
        
        // Limpiar checkboxes
        document.querySelectorAll('.availability-filter input[type="checkbox"], .language-filter input[type="checkbox"]').forEach(cb => {
            cb.checked = false;
        });
        
        // Limpiar radios
        document.querySelectorAll('.experience-filter input[type="radio"]').forEach(radio => {
            radio.checked = false;
        });
        
        filteredTutores = [...tutoresData];
        renderTutores(filteredTutores);
        updateResultsCount();
    }

    function renderTutores(tutores) {
        const container = document.getElementById('tutoresContainer');
        if (!container) return;

        if (tutores.length === 0) {
            container.innerHTML = `
                <div class="no-results">
                    <i class="fas fa-search" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>
                    <h3>No se encontraron tutores</h3>
                    <p>Intenta ajustar tus filtros de búsqueda</p>
                </div>
            `;
            return;
        }

        const tutoresHTML = tutores.map(tutor => createTutorCard(tutor)).join('');
        container.innerHTML = tutoresHTML;
        
        // Agregar clase de vista
        container.className = `tutores-container ${currentView === 'list' ? 'list-view' : ''}`;
        
        // Agregar event listeners a los botones
        container.querySelectorAll('.btn-ver-perfil').forEach(btn => {
            btn.addEventListener('click', function() {
                const tutorId = this.dataset.id;
                showTutorModal(tutorId);
            });
        });

        container.querySelectorAll('.btn-reservar-rapido').forEach(btn => {
            btn.addEventListener('click', function() {
                const tutorId = this.dataset.id;
                reservarClase(tutorId);
            });
        });
    }

    function createTutorCard(tutor) {
        const stars = '⭐'.repeat(Math.floor(tutor.rating)) + '☆'.repeat(5 - Math.floor(tutor.rating));
        const disponibilidadBadges = Object.values(tutor.disponibilidad)
            .filter(disp => disp !== 'no disponible')
            .slice(0, 3)
            .map(disp => `<span class="availability-badge ${disp === 'disponible' ? 'available' : ''}">${disp}</span>`)
            .join('');

        return `
            <div class="tutor-card ${currentView === 'list' ? 'list-view' : ''}">
                <div class="tutor-photo">
                    <img src="${tutor.foto}" alt="${tutor.nombre}" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCA4MCA4MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iNDAiIGN5PSI0MCIgcj0iNDAiIGZpbGw9IiM4YjVjZjYiLz4KPHN2ZyB4PSIyMCIgeT0iMjAiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIj4KPHBhdGggZD0iTTEyIDEyQzE0LjIwOTEgMTIgMTYgMTAuMjA5MSAxNiA4QzE2IDUuNzkwODYgMTQuMjA5MSA0IDEyIDRDOS43OTA4NiA0IDggNS43OTA4NiA4IDhDOCAxMC4yMDkxIDkuNzkwODYgMTIgMTIgMTJaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMTIgMTRDOC42ODYyOSAxNCA2IDE2LjY4NjMgNiAyMEgxOEMxOCAxNi42ODYzIDE1LjMxMzcgMTQgMTIgMTRaIiBmaWxsPSJ3aGl0ZSIvPgo8L3N2Zz4KPC9zdmc+'">
                </div>
                <div class="tutor-info">
                    <h3 class="tutor-name">${tutor.nombre}</h3>
                    <div class="tutor-subject">${getMateriaName(tutor.materia)}</div>
                    <div class="tutor-price">$${tutor.precio}/hora</div>
                    <div class="tutor-rating">
                        <span class="stars">${stars}</span>
                        <span class="count">(${tutor.rating})</span>
                    </div>
                    <div class="tutor-experience">${tutor.experiencia} de experiencia</div>
                    <div class="tutor-availability">
                        ${disponibilidadBadges}
                    </div>
                    <div class="tutor-actions">
                        <button class="btn-ver-perfil" data-id="${tutor.id}">Ver Perfil</button>
                        <button class="btn-reservar-rapido" data-id="${tutor.id}">Reservar</button>
                    </div>
                </div>
            </div>
        `;
    }

    function getMateriaName(materia) {
        const materias = {
            'matematicas': 'Matemáticas',
            'fisica': 'Física',
            'quimica': 'Química',
            'biologia': 'Biología',
            'historia': 'Historia',
            'literatura': 'Literatura',
            'ingles': 'Inglés',
            'filosofia': 'Filosofía'
        };
        return materias[materia] || materia;
    }

    function updateViewButtons() {
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.view === currentView) {
                btn.classList.add('active');
            }
        });
    }

    function updateResultsCount() {
        const countElement = document.getElementById('resultsCount');
        if (countElement) {
            countElement.textContent = `Mostrando ${filteredTutores.length} tutores`;
        }
    }

    function showTutorModal(tutorId) {
        const tutor = tutoresData.find(t => t.id == tutorId);
        if (!tutor) return;

        const modal = document.getElementById('tutorModal');
        
        // Llenar información del modal
        document.getElementById('tutorName').textContent = tutor.nombre;
        document.getElementById('tutorNameInfo').textContent = tutor.nombre;
        document.getElementById('tutorPhoto').src = tutor.foto;
        document.getElementById('tutorPhoto').alt = tutor.nombre;
        
        const stars = '⭐'.repeat(Math.floor(tutor.rating)) + '☆'.repeat(5 - Math.floor(tutor.rating));
        document.getElementById('tutorStars').innerHTML = stars;
        document.getElementById('tutorRating').textContent = `(${tutor.rating})`;
        document.getElementById('tutorPrice').textContent = `$${tutor.precio}/hora`;
        
        document.getElementById('tutorBio').textContent = tutor.biografia;
        
        // Materias
        const subjectsHTML = tutor.materias.map(materia => 
            `<span class="subject-badge">${materia}</span>`
        ).join('');
        document.getElementById('tutorSubjects').innerHTML = subjectsHTML;
        
        // Disponibilidad
        const availabilityHTML = createAvailabilityCalendar(tutor.disponibilidad);
        document.getElementById('tutorAvailability').innerHTML = availabilityHTML;
        
        // Reseñas
        const reviewsHTML = tutor.reseñas.map(review => `
            <div class="review-item">
                <div class="review-header">
                    <span class="review-author">${review.autor}</span>
                    <span class="review-rating">${'⭐'.repeat(review.rating)}</span>
                </div>
                <div class="review-text">${review.texto}</div>
            </div>
        `).join('');
        document.getElementById('tutorReviews').innerHTML = reviewsHTML;
        
        // Mostrar modal
        modal.style.display = 'flex';
    }

    function createAvailabilityCalendar(disponibilidad) {
        const dias = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
        const diasCompletos = ['lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo'];
        
        let html = '<div class="availability-calendar">';
        
        // Headers
        dias.forEach(dia => {
            html += `<div class="day-header">${dia}</div>`;
        });
        
        // Celdas
        diasCompletos.forEach(dia => {
            const disp = disponibilidad[dia];
            const className = disp === 'no disponible' ? 'unavailable' : 'available';
            const texto = disp === 'no disponible' ? 'No' : 'Sí';
            html += `<div class="day-cell ${className}">${texto}</div>`;
        });
        
        html += '</div>';
        return html;
    }

    function reservarClase(tutorId) {
        const tutor = tutoresData.find(t => t.id == tutorId);
        if (tutor) {
            alert(`Redirigiendo a reserva con ${tutor.nombre}...`);
            // Aquí se implementaría la lógica de reserva
        }
    }

    function setupTutorModal() {
        const modal = document.getElementById('tutorModal');
        const closeBtn = modal.querySelector('.close-modal');
        const btnReservar = modal.querySelector('.btn-reservar');
        const btnContactar = modal.querySelector('.btn-contactar');

        // Cerrar modal
        function closeModal() {
            modal.style.display = 'none';
        }

        if (closeBtn) {
            closeBtn.addEventListener('click', closeModal);
        }

        // Cerrar al hacer clic fuera del modal
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });

        // Botones del modal
        if (btnReservar) {
            btnReservar.addEventListener('click', function() {
                alert('Redirigiendo al sistema de reservas...');
                closeModal();
            });
        }

        if (btnContactar) {
            btnContactar.addEventListener('click', function() {
                alert('Abriendo chat con el tutor...');
                closeModal();
            });
        }
    }
});
